<!DOCTYPE html>
<html>
 <head>
  <title> File System </title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
   .box{
    height:0px;
    width:300px;
    margin: auto;
    background-color: transparent;
    padding: 16px 20px;
   }
   .has-error
   {
    border-color:white;
    background-color:white; 
   
   }
   body {
        background-image: url("/isometric-computer.gif");
        background-repeat: no-repeat;
        background-size: cover;
        height: 500px;
        }

  </style>
 </head>
 <body>
  <br />
  <br /> 
  <br />
  <div class="container box">
   <h3 align="center">Send File</h3><br />
   @if (count($errors) > 0)
    <div class="alert alert-danger">
     <button type="button" class="close" data-dismiss="alert">×</button>
     <ul>
      @foreach ($errors->all() as $error)
       <li>{{ $error }}</li>
      @endforeach
     </ul>
    </div>
   @endif
   @if ($message = Session::get('success'))
   <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
           <strong>{{ $message }}</strong>
   </div>
   @endif

<form method="post" action="{{ route('sendemail.store') }}" enctype="multipart/form-data" role="form" class="form-horizontal" id="location">
    {{ csrf_field() }}
    <div class="form-group">
     <label>Enter Your Name</label>
     <input type="text" name="name" class="form-control" />
    </div>
    <div class="form-group">
     <label>Enter Your Email</label>
     <input type="text" name="email" class="form-control"  />
    </div>

    <div class="form-group">
            <label for="resume" placeholder="(resume type *PDF*)">Document:<span class="text-danger font-weight-bold">*</span></label>
            <input type="file" class="w-100 p-1" name="image" value="{{old('resume')}}"/>
            
    </div>
    <div class="form-group">
     <input type="submit" name="send" class="btn btn-primary" value="Send" />
    </div>
   </form>

  </div>
 </body>
</html>